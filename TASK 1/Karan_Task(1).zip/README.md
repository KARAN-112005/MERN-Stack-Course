
# TASK 1
Creating a index.html file , printing "Hello World!" on screen.
## How to Run
1. Clone or download this project repository to your local machine.
2. Locate the `index.html` file in the root directory.
3. Double-click the `index.html` file to open and run it directly in any modern web browser.

