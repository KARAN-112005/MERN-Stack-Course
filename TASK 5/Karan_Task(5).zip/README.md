# Laundry Service - Hero Section

A static web page implementing the **Hero Section** of a laundry service web application, built with plain HTML and CSS (no frameworks, no flexbox).

---

## 📁 Project Structure

```
project/
├── index.html      # HTML structure
├── style.css       # All styles
└── README.md       # Project documentation
```

---

## 📄 Pages & Sections

### Navbar
- **Logo** on the left
- **Navigation links** in the center: Home, Services, About Us, Contact Us
- **Username** button on the right with a blue border
- Layout built using `display: inline-block` — no flexbox used

### Hero Section
- Two side-by-side `div`s using `display: inline-block`
- **Left div** — Heading, description text, and a "Book a service today!" CTA button
- **Right div** — Washing machine image
- Uses `height: 100vh` so the section fills the full viewport without scrolling

---

## 🛠️ Tech Stack

| Technology | Usage |
|---|---|
| HTML5 | Page structure |
| CSS3 | Styling and layout |

---

## 🚀 How to Run

1. Download or clone the project folder
2. Make sure `index.html` and `style.css` are in the **same folder**
3. Open `index.html` in any browser

No installations or build tools required.

---

## 🎨 Design Details

- **Primary color:** `#1a90d9` (blue) — used for highlights, button, and username border
- **Heading color:** `#1a1a2e` (dark navy)
- **Body text color:** `#555` (muted grey)
- **Font:** Segoe UI / Arial (system fonts)
- **Layout technique:** `display: inline-block` with `vertical-align: middle`
- **Viewport fit:** `height: 100vh` on the hero section — no scroll

---

## ✅ Requirements Implemented

- [x] Navbar with Logo, nav links, and Username
- [x] `display: inline-block` used for layout (no flexbox)
- [x] Hero section with two divs (left content + right image)
- [x] Heading with blue highlighted text
- [x] Description paragraph
- [x] "Book a service today!" button
- [x] Viewport units used — fits screen without scroll
- [x] HTML and CSS in separate files
